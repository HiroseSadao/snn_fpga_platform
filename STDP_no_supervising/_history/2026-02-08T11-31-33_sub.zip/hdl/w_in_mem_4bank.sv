`default_nettype none

module w_in_mem_4bank #(
    parameter int N_IN = 784,
    parameter int N_NEURONS = 100,
    parameter logic signed [31:0] INIT_VAL = 32'sd66,
    parameter bit INIT_FROM_FILE = 0
) (
    input  wire                         clk,
    input  wire                         rst,

    input  wire                         r_en,
    input  wire [$clog2(N_NEURONS)-1:0] r_neuron0,
    input  wire [$clog2(N_NEURONS)-1:0] r_neuron1,
    input  wire [$clog2(N_IN)-1:0]      r_in0,
    input  wire [$clog2(N_IN)-1:0]      r_in1,
    output logic signed [31:0]          r_data0,
    output logic signed [31:0]          r_data1,

    input  wire                         w_en0,
    input  wire                         w_en1,
    input  wire [$clog2(N_NEURONS)-1:0] w_neuron0,
    input  wire [$clog2(N_NEURONS)-1:0] w_neuron1,
    input  wire [$clog2(N_IN)-1:0]      w_in0,
    input  wire [$clog2(N_IN)-1:0]      w_in1,
    input  wire signed [31:0]           w_data0,
    input  wire signed [31:0]           w_data1,

    input  wire                         dbg_en,
    input  wire [$clog2(N_NEURONS)-1:0] dbg_neuron,
    input  wire [$clog2(N_IN)-1:0]      dbg_in,
    output logic                        dbg_valid,
    output logic signed [31:0]          dbg_data,

    output logic                        init_done
);

    localparam int LANES = 2;
    localparam int NEURON_GROUPS = (N_NEURONS + LANES - 1) / LANES;
    localparam int DEPTH = NEURON_GROUPS * N_IN;
    localparam int ADDR_W = (DEPTH <= 1) ? 1 : $clog2(DEPTH);

    (* ram_style = "block" *) logic signed [31:0] mem0 [0:DEPTH-1];
    (* ram_style = "block" *) logic signed [31:0] mem1 [0:DEPTH-1];
    // Two banks for BRAM-friendly dual-port inference

    initial begin
        if (INIT_FROM_FILE) begin
            $readmemh("data/w_init0.mem", mem0);
            $readmemh("data/w_init1.mem", mem1);
            // Expect 2-bank initialization files (even/odd neurons)
        end
    end

    logic dbg_pending;
    logic dbg_bank;
    logic signed [31:0] dbg_data0;
    logic signed [31:0] dbg_data1;
    wire  [ADDR_W-1:0] dbg_addr_i = addr_from(dbg_neuron, dbg_in);

    function automatic [ADDR_W-1:0] addr_from;
        input int neuron;
        input int in_idx;
        int row;
        begin
            row = neuron >> 1; // divide by 2
            addr_from = row * N_IN + in_idx;
        end
    endfunction

    logic init_active;
    logic [ADDR_W-1:0] init_addr;

    always_ff @(posedge clk) begin
        if (rst) begin
            r_data0 <= INIT_VAL;
            r_data1 <= INIT_VAL;
            dbg_valid <= 1'b0;
            dbg_data <= INIT_VAL;
            dbg_pending <= 1'b0;
            dbg_bank <= 1'b0;
            init_active <= !INIT_FROM_FILE;
            init_addr <= '0;
            init_done <= INIT_FROM_FILE;
        end else begin
            if (init_active) begin
                mem0[init_addr] <= INIT_VAL;
                mem1[init_addr] <= INIT_VAL;

                dbg_valid <= 1'b0;
                dbg_data <= INIT_VAL;
                dbg_pending <= 1'b0;

                if (init_addr == DEPTH-1) begin
                    init_active <= 1'b0;
                    init_done <= 1'b1;
                end else begin
                    init_addr <= init_addr + 1'b1;
                end
            end else begin
                if (r_en) begin
                    r_data0 <= mem0[addr_from(r_neuron0, r_in0)];
                    r_data1 <= mem1[addr_from(r_neuron1, r_in1)];
                end

                if (w_en0) mem0[addr_from(w_neuron0, w_in0)] <= w_data0;
                if (w_en1) mem1[addr_from(w_neuron1, w_in1)] <= w_data1;

                dbg_valid <= 1'b0;
                if (dbg_pending) begin
                    case (dbg_bank)
                        1'b0: dbg_data <= dbg_data0;
                        1'b1: dbg_data <= dbg_data1;
                        default: dbg_data <= INIT_VAL;
                    endcase
                    dbg_valid <= 1'b1;
                end

                dbg_pending <= dbg_en;
                if (dbg_en) begin
                    dbg_bank <= dbg_neuron[0];
                end
            end
        end
    end

    // Debug read port (second port) for BRAM inference
    always_ff @(posedge clk) begin
        if (rst) begin
            dbg_data0 <= INIT_VAL;
        end else if (!init_active && dbg_en && (dbg_neuron[0] == 1'b0)) begin
            dbg_data0 <= mem0[dbg_addr_i];
        end
    end

    always_ff @(posedge clk) begin
        if (rst) begin
            dbg_data1 <= INIT_VAL;
        end else if (!init_active && dbg_en && (dbg_neuron[0] == 1'b1)) begin
            dbg_data1 <= mem1[dbg_addr_i];
        end
    end

endmodule

`default_nettype wire
