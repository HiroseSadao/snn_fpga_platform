`timescale 1ns / 1ps
`default_nettype none

module pixel_reconstruct
    #(
        parameter HCOUNT_WIDTH = 11,
        parameter VCOUNT_WIDTH = 10
    )
    (
     input wire                         clk,
     input wire                         rst,
     input wire                         camera_pclk,
     input wire                         camera_h_sync,
     input wire                         camera_v_sync,
     input wire [7:0]                   camera_data,
     output logic                       pixel_valid,
     output logic [HCOUNT_WIDTH-1:0]    pixel_h_count,
     output logic [VCOUNT_WIDTH-1:0]    pixel_v_count,
     output logic [15:0]                pixel_data
     );
    // your code here! and here's a handful of logics that you may find helpful to utilize.

    // previous value of PCLK
    logic  pclk_prev;
    logic sample_en;// 1 when we should sample camera_* signals
    // can be assigned combinationally:
    //  true when pclk transitions from 0 to 1
    logic camera_sample_valid;
    assign camera_sample_valid = sample_en; // TODO: fix this assign
    // previous value of camera data, from last valid sample!
    // should NOT update on every cycle of clk, only
    // when samples are valid.
    logic last_sampled_hs, last_sampled_vs;
    logic [7:0] last_sampled_data;
    // flag indicating whether the last byte has been transmitted or not.
    logic half_pixel_ready;
    logic [7:0] hi_byte;

    always_ff @(posedge clk) begin
        if (rst) begin
            pclk_prev <= 1'b0;
        end else begin
            pclk_prev <= camera_pclk;
        end
    end

    assign sample_en = (~pclk_prev) & camera_pclk;
    logic active;
    assign active = camera_h_sync & camera_v_sync;

    logic hs_now, vs_now;

    // 追加
    logic pending_row_reset;   // HS落下後、次のpixel_validで行頭処理をするフラグ
    logic bump_h_on_next;      // 直前にpixelを出したので、次のpixelでh_countを+1する
    logic will_emit_pixel;

    always_ff @(posedge clk) begin
        if (rst) begin
            pclk_prev        <= 1'b0;
            last_sampled_hs  <= 1'b0;
            last_sampled_vs  <= 1'b0;
            last_sampled_data<= 8'h00;

            half_pixel_ready <= 1'b0;
            hi_byte          <= 8'h00;

            pixel_valid      <= 1'b0;
            pixel_data       <= 16'h0000;

            pixel_h_count    <= '0;
            pixel_v_count    <= '0;

            pending_row_reset<= 1'b0;
            bump_h_on_next   <= 1'b0;
        end else begin
            pixel_valid <= 1'b0;

            if (sample_en) begin
                // 現在の同期信号をサンプル
                hs_now = camera_h_sync;
                vs_now = camera_v_sync;

                // ▼フレーム境界（v_sync=0 は即座にフレームリセット）
                if (~vs_now) begin
                    pixel_h_count     <= '0;
                    pixel_v_count     <= '0;
                    half_pixel_ready  <= 1'b0;
                    pending_row_reset <= 1'b0;
                    bump_h_on_next    <= 1'b0;
                end else begin
                    // ▼行末（HS 1→0）は「次のpixel_validで」処理するよう予約
                    if (last_sampled_hs & ~hs_now) begin
                        pending_row_reset <= 1'b1; // 次の有効ピクセルで行頭化
                        half_pixel_ready  <= 1'b0; // 行またぎのバイト結合は禁止
                    end
                end

                // このサンプルでピクセルが完成するか（=前回が上位8bitを保持中）
                will_emit_pixel = active & half_pixel_ready;

                // ▼行頭/インクリメントの“実行タイミング”を、ピクセル完成に合わせて制御
                if (will_emit_pixel) begin
                    if (pending_row_reset) begin
                        // 行境界はここ（次のpixel_valid）で反映
                        pixel_h_count     <= '0;                 // 先頭は 0 で表示
                        pixel_v_count     <= pixel_v_count + 1'b1;
                        pending_row_reset <= 1'b0;
                    end else if (bump_h_on_next) begin
                        // 通常は「前のpixelの次」にカウントを進める
                        pixel_h_count <= pixel_h_count + 1'b1;
                    end
                    // 次のピクセルで h_count を進める予約をセット
                    bump_h_on_next <= 1'b1;
                end

                // ▼ピクセルの組み立て
                if (active) begin
                    if (!half_pixel_ready) begin
                        hi_byte          <= camera_data;   // 上位8bit取り込み
                        half_pixel_ready <= 1'b1;
                    end else begin
                        pixel_data       <= {hi_byte, camera_data}; // 下位8bitで完成
                        pixel_valid      <= 1'b1;
                        half_pixel_ready <= 1'b0;
                        // ※ここでは h_count を増やさない（次の pixel_valid で増える）
                    end
                end else begin
                    half_pixel_ready <= 1'b0; // ブランキング中は破棄
                end

                // 次サンプル用に保持
                last_sampled_hs   <= hs_now;
                last_sampled_vs   <= vs_now;
                last_sampled_data <= camera_data;
            end
        end
    end
endmodule

`default_nettype wire
