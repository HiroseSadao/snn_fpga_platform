`default_nettype none
module center_of_mass (
        input wire clk,
        input wire rst,
        input wire [10:0] pixel_x,
        input wire [9:0]  pixel_y,
        input wire pixel_valid,
        input wire calculate,
        output logic [10:0] com_x,
        output logic [9:0] com_y,
        output logic com_valid
    );
    // REPLACE ME!
    assign com_valid = 0;
    //your code here
endmodule

`default_nettype wire



