# file: sim/traffic_generator_tb.py
import os
from pathlib import Path
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ClockCycles


async def tick(dut, n=1):
    await ClockCycles(dut.clk, n)


@cocotb.test()
async def traffic_generator_smoke_test(dut):
    """
    Minimal-but-meaningful test for traffic_generator:
      - Alternating RD/WR state machine
      - Write path: handshake, memrequest_en/we, write_address progression, TLAST reset behavior (indirect)
      - Read path: request issue -> (delayed) memrequest_complete -> read_axis_valid/data
    """
    # --- Clock start ---
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())

    # --- Default drives ---
    dut.rst.value = 1
    dut.memrequest_busy.value = 0
    dut.memrequest_complete.value = 0
    dut.memrequest_resp_data.value = 0

    dut.write_axis_data.value = 0
    dut.write_axis_tlast.value = 0
    dut.write_axis_valid.value = 0

    dut.read_axis_ready.value = 1
    dut.read_axis_af.value = 0

    # --- Reset ---
    await tick(dut, 5)
    dut.rst.value = 0
    await tick(dut, 3)

    # Helper: simple "memory controller" that completes requests 1 cycle later
    pending = []  # list of (addr, is_write)
    issued_reads = 0
    completed_reads = 0
    issued_writes = 0

    async def mem_model():
        pending = []
        while True:
            await RisingEdge(dut.clk)

            # 発行取り込み：アドレスが解決可能かチェック
            if int(dut.memrequest_en.value) == 1:
                bv_addr = dut.memrequest_addr.value
                bs = str(bv_addr.binstr).lower()
                if ('x' in bs) or ('z' in bs):
                    # アドレス未定義ならこの周期は取り込まない
                    continue

                addr = int(bv_addr)
                is_wr = int(dut.memrequest_write_enable.value)
                pending.append((addr, is_wr))

            # 完了を1サイクル/個ペースで返す
            if pending:
                addr, is_wr = pending.pop(0)
                dut.memrequest_complete.value = 1
                if is_wr == 0:
                    dut.memrequest_resp_data.value = ((addr & 0xFFFF) << 16) | (addr & 0xFFFF)
                else:
                    dut.memrequest_resp_data.value = 0
            else:
                dut.memrequest_complete.value = 0

    cocotb.start_soon(mem_model())

    # --- Phase A: exercise WR_CAM path with TLAST reset semantics ---
    # Drive a sequence of write handshakes across WR_CAM slots.
    # Since state alternates every cycle, we just keep valid=1; WR handshakes happen when WR_CAM is active.
    write_values = [0x11, 0x22, 0x33]
    tlast_on_idx = 2  # assert TLAST together with the 3rd write handshake
    seen_wr_addrs = []

    dut.write_axis_valid.value = 1
    for i, w in enumerate(write_values):
        # Wait until DUT is in WR_CAM and not busy so that write handshake can occur
        # (write_axis_ready should be 1 in WR_CAM when not busy)
        max_wait = 50
        while int(dut.write_axis_ready.value) == 0 and max_wait > 0:
            await tick(dut, 1)
            max_wait -= 1
        assert int(dut.write_axis_ready.value) == 1, "write_axis_ready must assert in WR_CAM"

        # Present data and, optionally, TLAST for this handshake
        dut.write_axis_data.value = w
        dut.write_axis_tlast.value = 1 if i == tlast_on_idx else 0

        # One cycle for the handshake
        await tick(dut, 1)

        # On the handshake cycle, memrequest should be a write
        assert int(dut.memrequest_en.value) == 1, "[WR] memrequest_en should assert on write handshake"
        assert int(dut.memrequest_write_enable.value) == 1, "[WR] memrequest_write_enable should be 1"

        seen_wr_addrs.append(int(dut.memrequest_addr.value))
        issued_writes += 1

        # Deassert TLAST after the handshake
        dut.write_axis_tlast.value = 0

        # Give the mem model a cycle to pop
        await tick(dut, 1)

    # We expect addresses to be 0,1,2 for the first three write handshakes.
    assert seen_wr_addrs[:3] == [0, 1, 2], f"Unexpected write addresses: {seen_wr_addrs[:3]}"

    # Now verify that after TLAST handshake, the NEXT write starts back at 0
    # Do one more write handshake
    # Wait for WR_CAM slot again
    max_wait = 50
    while int(dut.write_axis_ready.value) == 0 and max_wait > 0:
        await tick(dut, 1)
        max_wait -= 1
    assert int(dut.write_axis_ready.value) == 1

    dut.write_axis_data.value = 0x44
    dut.write_axis_tlast.value = 0
    await tick(dut, 1)
    assert int(dut.memrequest_en.value) == 1
    assert int(dut.memrequest_write_enable.value) == 1
    addr_after_reset = int(dut.memrequest_addr.value)
    issued_writes += 1
    await tick(dut, 1)

    assert addr_after_reset == 0, f"Write address should reset to 0 after TLAST handshake; got {addr_after_reset}"

    # --- Phase B: exercise RD_HDMI path (read requests and completions) ---
    # Keep FIFO not-almost-full and mem not-busy so reads are issued every RD state.
    # The mem model completes one command per cycle; we count only reads here.
    target_read_issues = 10
    while issued_reads < target_read_issues:
        await RisingEdge(dut.clk)
        # count a READ issue when memrequest_en==1 and write_enable==0
        if int(dut.memrequest_en.value) == 1 and int(dut.memrequest_write_enable.value) == 0:
            issued_reads += 1

    # Allow completions to flush through
    for _ in range(20):
        await tick(dut, 1)

    # Check that some read_axis_valid pulses were seen
    # (We can't directly sample pulses without a monitor; instead, assert consistency via counts)
    assert completed_reads >= target_read_issues // 2, (
        f"Too few read completions observed: {completed_reads}"
    )

    # Basic sanity on read_axis outputs right when complete pulses happen:
    # Step a few cycles and whenever memrequest_complete=1 and the completed cmd was a READ,
    # read_axis_valid should be 1 and data should be non-zero (we encoded addr)
    checks = 0
    for _ in range(30):
        await RisingEdge(dut.clk)
        if int(dut.memrequest_complete.value) == 1:
            # If the completed command was a write, read_axis_valid should be 0
            # If it was a read, read_axis_valid should be 1 and data should carry our pattern
            # We infer "was read" by read_axis_valid itself.
            if int(dut.read_axis_valid.value) == 1:
                val = int(dut.read_axis_data.value)
                assert val != 0, "Read completion should present non-zero data (addr-encoded)"
                checks += 1

    assert checks > 0, "No readable completions observed on read_axis_valid"

    # --- Phase C: read_axis_tlast should be 0 in this short run (MAX_ADDR is huge) ---
    assert int(dut.read_axis_tlast.value) == 0, "TLAST should remain 0 in short tests (no wrap yet)"


def traffic_generator_runner():
    from cocotb.runner import get_runner

    sim = os.getenv("SIM", "icarus")  # "icarus" or "verilator"
    proj_root = Path(__file__).resolve().parents[1]  # .../lab06/
    hdl_file = proj_root / "hdl" / "traffic_generator.sv"
    evt_file = proj_root / "hdl" / "evt_counter.sv"
    cf_file = proj_root / "hdl" / "command_fifo.sv"

    runner = get_runner(sim)
    runner.build(
        sources=[str(hdl_file), str(evt_file), str(cf_file)],
        hdl_toplevel="traffic_generator",
        timescale=("1ns", "1ps"),
        waves=True,
        always=True,
        build_dir=str(proj_root / "sim" / "sim_build"),
    )
    runner.test(
        hdl_toplevel="traffic_generator",
        test_module=Path(__file__).stem,
        seed=None,
    )


if __name__ == "__main__":
    traffic_generator_runner()