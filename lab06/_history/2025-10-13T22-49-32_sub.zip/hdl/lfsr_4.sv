`timescale 1ns/1ps
`default_nettype none

module lfsr_4 (
    input  logic        clk,
    input  logic        rst,
    input  logic [3:0]  seed,
    output logic [3:0]  q
);

    always_ff @(posedge clk) begin
        if (rst) begin
            q <= seed;
        end else begin
            logic [3:0] next;
            next[3] = q[2];
            next[2] = q[1];
            next[1] = q[0] ^ q[3];
            next[0] = q[3];
            q <= next;
        end
    end

endmodule

`default_nettype wire
