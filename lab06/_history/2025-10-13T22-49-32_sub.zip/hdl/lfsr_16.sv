`timescale 1ns / 1ps
`default_nettype none

module lfsr_16 (
        input  wire        clk,
        input  wire        rst,
        input  wire [15:0] seed,
        output logic [15:0] q
    );

    always_ff @(posedge clk) begin
        if (rst) begin
            q <= seed;
        end else begin
            logic [15:0] next;

            next[15] = q[14] ^ q[15];
            next[14] = q[13];
            next[13] = q[12];
            next[12] = q[11];
            next[11] = q[10];
            next[10] = q[9];
            next[9]  = q[8];
            next[8]  = q[7];
            next[7]  = q[6];
            next[6]  = q[5];
            next[5]  = q[4];
            next[4]  = q[3];
            next[3]  = q[2];
            next[2]  = q[1] ^ q[15];
            next[1]  = q[0];
            next[0]  = q[15];

            q <= next;
        end
    end

endmodule

`default_nettype wire
