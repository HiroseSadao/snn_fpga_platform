# file: sim/lif_test.py
import os
from pathlib import Path
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ClockCycles


CLK_PERIOD_NS = 0.5  # 2 GHz (matches current test speed)


def set_default_inputs(dut):
    dut.start.value = 0
    dut.tick.value = 0


async def reset_and_start(dut):
    set_default_inputs(dut)
    await ClockCycles(dut.clk, 2)
    dut.start.value = 1
    await ClockCycles(dut.clk, 1)
    dut.start.value = 0
    await ClockCycles(dut.clk, 2)


def ref_lif_spike_count(steps):
    # Fixed-point S16.16 reference model (matches lif.sv)
    FP_SHIFT = 16
    FP_SCALE = 1 << FP_SHIFT
    V_REST = -60
    V_RESET = -65
    V_THR = -40
    I_IN = 21
    TAU_M = 200
    REFRACT = 40

    v_mem = V_RESET * FP_SCALE
    refr_cnt = 0
    spike_count = 0

    for _ in range(steps):
        if refr_cnt != 0:
            refr_cnt -= 1
            v_mem = V_RESET * FP_SCALE
            continue

        num = (V_REST * FP_SCALE) - v_mem + (I_IN * FP_SCALE)
        # trunc toward zero
        dv = int(num / TAU_M)
        v_next = v_mem + dv

        if v_next >= (V_THR * FP_SCALE):
            spike_count += 1
            v_mem = V_RESET * FP_SCALE
            refr_cnt = REFRACT
        else:
            v_mem = v_next

    return spike_count


async def lif_step(dut):
    dut.tick.value = 1
    await RisingEdge(dut.clk)
    dut.tick.value = 0
    await ClockCycles(dut.clk, 20)


@cocotb.test()
async def lif_count_test(dut):
    cocotb.start_soon(Clock(dut.clk, CLK_PERIOD_NS, units="ns").start())

    await reset_and_start(dut)

    steps = 120
    for _ in range(steps):
        await lif_step(dut)

    expected = ref_lif_spike_count(steps)
    got = int(dut.spike_count.value)
    assert got == expected, f"spike_count mismatch: exp {expected} got {got}"


def lif_runner():
    from cocotb.runner import get_runner
    sim = os.getenv("SIM", "icarus")
    repo_root = Path(__file__).resolve().parents[1]
    hdl_dir = repo_root / "hdl"

    sv_sources = [str(p) for p in hdl_dir.glob("**/*.sv")]

    runner = get_runner(sim)
    runner.build(
        sources=sv_sources,
        hdl_toplevel="lif",
        parameters={},
        timescale=("1ns", "1ps"),
        waves=True,
        always=True,
        build_dir=str(repo_root / "sim" / "sim_build_lif"),
    )
    runner.test(
        hdl_toplevel="lif",
        test_module=Path(__file__).stem,
        seed=None,
    )


if __name__ == "__main__":
    lif_runner()
